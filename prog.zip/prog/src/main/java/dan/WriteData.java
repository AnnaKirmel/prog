package dan;
import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.net.URL;

public class WriteData {

    public static void main(String[] args) throws Exception {
        URL fileUrl = WriteData.class.getClassLoader().getResource("Data.csv");

        CSVWriter writer = new CSVWriter(new FileWriter(fileUrl.getFile()));


        String[] record = "122221,firearms,AK-47,1000,30,3.63,40".split(",");


        writer.writeNext(record, false);


        writer.close();
    }
}
